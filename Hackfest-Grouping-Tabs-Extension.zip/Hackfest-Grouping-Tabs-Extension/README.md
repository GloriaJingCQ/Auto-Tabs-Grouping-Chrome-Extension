# Hackfest-Grouping-Tabs-Extension

## Prerequisite
Please upgrade your chrome to the latest version, so chrome.tabGroups Api is enabled.